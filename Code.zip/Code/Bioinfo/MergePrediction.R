## Merge Predition Output file
## dali.sun@ndsu.edu
library(tidyverse)
library(data.table)
#library(plyr)
#library(dplyr)
BiocManager::install(c("Biostrings"))

## Select folder for merging
if (interactive() && .Platform$OS.type == "windows")
  path=choose.dir(getwd(), "Choose a suitable folder")
setwd(path)

## Merge files
tbl <-
  list.files(path, pattern = "*.csv") %>% 
  map_df(~read_csv(.,  col_names = FALSE, col_types = cols(.default = "c")));

names(tbl)[1] <- "ACCID";
names(tbl)[2] <- "SSeq";

## reshape concate duplicated by Uniprot ID

ttb<-tbl %>% group_by(ACCID) %>% summarize(SSeq = paste(SSeq, collapse = ''))

library(NLP)

library(Biostrings)

seq<-ttb$SSeq;
idl<-ttb$ACCID;

## frequency statistics
FreqStat<-function (seq){
  fre<-seq %>% strsplit(split="") %>% table %>% prop.table;
  frerslt<-as.data.frame(fre);
  cc=ifelse(( 'C' %in% frerslt$.),frerslt$Freq[frerslt$.=="C"], 0);
  ee=ifelse(( 'E' %in% frerslt$.),frerslt$Freq[frerslt$.=="E"], 0);
  hh=ifelse(( 'H' %in% frerslt$.),frerslt$Freq[frerslt$.=="H"], 0);
  return (c(cc,ee,hh));
}

rslt<-lapply(seq,FreqStat);
rslts<-do.call(rbind, rslt);
rsltstbl<-cbind(idl, rslts);

colnames(rsltstbl) = c('ID', 'C', 'E','H');
df<-as.data.frame(rsltstbl);


#library(validate)
## Convert factor to numeric
df$C<-as.double(as.character(df$C));
df$E<-as.double(as.character(df$E));
df$H<-as.double(as.character(df$H));
## Row validation
dff<-df[ ! (df$C +df$H+ df$E)>1.1, ];

path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), "SimulationResult.csv")
write.csv(dff,file=path)

