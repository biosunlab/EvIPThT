## Commbinding Proteomics Simulation and Bioinformation result

## Calculate betasheet Per proteomics result file.

## Input Simulation and Bioinformatics result
library(readr)
SI <- read_csv("MergeSimInfo.csv")


#read contamination list
library(readr)
cpf <- read_csv("ConProList.csv")
cpl<-str_extract(cpf$Des, "(?<=\\().+?(?=\\))")


#input


# Start

library(readxl)
library(dplyr)
library(tidyverse)
library(data.table)
library("fs")





## read proteomic file and calculation
readpro<-function(fp){
  file<-read_excel(fp);

  #containation removal
  file<-file %>% filter(str_detect(`Cellular Component`, 'cytoplasm|extracellular'))

  file$Q<-file$emPAI/sum(file$emPAI);
  PL<-select(file,'Accession','Q');
  names(PL)[1] <- "ID";

  total <- merge(PL,SI,by=c("ID"),all.x = TRUE)
  total$BPP<-total$Q*total$BP;
  total$HPP<-total$Q*total$HP;
  total$TPP<-total$Q*total$TP;

  BP<-sum(total$BPP);
  HP<-sum(total$HPP);
  TP<-sum(total$TPP);
  n<-nrow(total);
  fn<-path_file(fp);
  rslt<-c(fn,BP,HP,TP,n);

  return (rslt);
}

# Read All Proteomic result
path="%Your Local Data File%DataUse/Proteomics/";
fl <-list.files(path, pattern = "*.xlsx", recursive = TRUE,full.names = T);
rslts<-lapply(fl,readpro)


rslt<-do.call(rbind, rslts);
colnames(rslt) = c('File', 'Beta', 'Helix','Coil','Number');
# Write Secondary Structure sumary by files
path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), "SSReultList.csv")
write.csv(rslt,file=path)

# New solution

#input

# HC, HE, MC, ME
Spl='HE'
# Start

library(readxl)
library(dplyr)
fp=paste("%Your Local Data File%DataUse/Proteomics/", Spl,sep="")

files <- list.files(path = fp , pattern = "*.xlsx",full.names = T)
exlf <- sapply(files, read_excel, simplify=FALSE)

calQ<-function (df){
  df$Q<-df$emPAI/sum(df$emPAI)
  #df$Q<-df$`# PSMs`/sum(df$`# PSMs`);
  return (df)
}


exlf<-map(exlf, calQ)
combined<-bind_rows(exlf, .id = "id")
# Remove contamnaitent
filtered<-combined %>%
  filter(!`Accession` %in% cpl) %>%
  #cell
  filter(str_detect(`Cellular Component`, 'cytoplasm')) %>%
  filter(!str_detect(`Cellular Component`, 'extracellular'))
  #EV 
  #filter(str_detect(`Cellular Component`, 'cytoplasm'))


# 
#Mitochondrion 
filtered<-filtered %>%

  filter(str_detect(`Cellular Component`, 'mitochondrion'))

PL<-select(filtered,'Accession','Q')
#PLNR<-PL
PLNR<-PL[duplicated(PL$Accession),]
PLag<-aggregate(PLNR$Q,list(Accession=PLNR$Accession),mean)

PLag$Q<-PLag$x/sum(PLag$x)

PL<-select(PLag,'Accession','Q');
names(PL)[1] <- "ID";
names(PL)[2] <- "Q";

total <- merge(PL,SI,by=c("ID"),all.x = TRUE)
total$BPP<-total$Q*total$BP;
total$HPP<-total$Q*total$HP;
total$TPP<-total$Q*total$TP;

BP<-sum(total$BPP);
HP<-sum(total$HPP);
TP<-sum(total$TPP);

#BPc=BP/length(total$BPP);
tt<- total %>% select(ID, Q, BP)
path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), paste(Spl,"csv", sep="."))
# Mitochondiron
path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), paste(Spl,"csv", sep="_MO."))

write.csv(tt,file=path)



# Get exclusive protein list (HC vs MC)
HC <- read_csv("HC.csv")
MC <- read_csv("MC.csv")

HCe<-HC %>%  filter(!ID %in% MC$ID)%>% select(ID, Q, BP) #%>% mutate(Q = Q/sum(Q))
MCe<-MC %>%  filter(!ID %in% HC$ID)%>% select(ID, Q, BP) #%>% mutate(Q = Q/sum(Q))
path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), 'HC_Ex.csv')
write.csv(HCe,file=path)
path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), 'MC_Ex.csv')
write.csv(MCe,file=path)


