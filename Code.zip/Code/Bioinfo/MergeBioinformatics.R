## Merge Bioinformatics result file
## dali.sun@ndsu.edu
library(tidyverse)
library(data.table)

## Select folder for merging
if (interactive() && .Platform$OS.type == "windows")
  path=choose.dir(getwd(), "Choose a suitable folder")
setwd(path)

## Merge files
tbl <-
  list.files(path, pattern = "PSM.csv$", recursive = TRUE) %>% 
  map_df(~read_csv(.,  col_names = TRUE, col_types = cols(.default = "c")));

names(tbl)[2] <- "ID";

# remove duplication
BioRslt<-tbl %>% distinct(ID,.keep_all = TRUE)

SimRslt<- read_csv("~/SecStructBioinfo/SimulationResult.csv")

total <- merge(BioRslt,SimRslt,by=c("ID"),all = TRUE)

## Change A4D174 to UPI00001406E1
#ttl2<-total
#ttl2$ID[ttl2$PID=='A4D174']<-'UPI00001406E1'

# remove know to NA
total$unknown[total$unknown == 1] <- NA
total$`Partial Known`[total$`Partial Known` == 0]<- NA


## Convert Colum Type
total$Beta.strandi<-as.numeric(total$Beta.strandi);
total$Helixi<-as.numeric(total$Helixi);
total$Turni<-as.numeric(total$Turni);
total$seq_length<-as.numeric(total$seq_length);
total$`Partial Known`<-as.numeric(total$`Partial Known`);

tt1<- total %>% mutate(BPP = ((`Partial Known`*`Beta.strandi`)+(1-`Partial Known`)*E)) %>% 
  mutate(HPP = ((`Partial Known`*`Helixi`)+(1-`Partial Known`)*H)) %>% 
  mutate(TPP = ((`Partial Known`*`Turni`)+(1-`Partial Known`)*C))

tt2<-tt1 %>% mutate(BP = ifelse(is.na(`Beta.strandi`),E,BPP)) %>% 
  mutate(HP = ifelse(is.na(`Helixi`),H,HPP)) %>% 
  mutate(TP = ifelse(is.na(`Turni`),C,TPP))

tt<- tt2 %>% select(ID, BP, HP, TP)
path<-file.path(dirname(rstudioapi::getSourceEditorContext()$path), "MergeSimInfo.csv")
write.csv(tt,file=path)

