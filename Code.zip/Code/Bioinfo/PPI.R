## PPI 

## Prepare list for PPI search
library(readr)
library(UniprotR)
library(STRINGdb)
library(readxl)
library(dplyr)


GetPPI<-function(Spl){
  #Spl='MC'
  df <- read_csv(paste(Spl,".csv",sep=""))
  #Convert String ID
  Sid<-ConvertID(df$ID,"ACC+ID", "STRING_ID")
  PLF<-merge(df,Sid, by.x="ID", by.y="From_UniProtKB_AC_ID")
  PLF<-PLF[PLF$`To STRING_ID`!="",] #remove empty STRING_ID
  PLF<-PLF[order(-PLF$Q),] # order the df in desceding by emPAI
  
  get_STRING_species(version="10", species_name=NULL)
  #human species 9606
  string_db <- STRINGdb$new( version="10", species=9606,score_threshold=0, input_directory="" )
  PPIdf<-string_db$get_interactions(PLF$`To STRING_ID`)
  PLF_Rank<-select(PLF,`To STRING_ID`,'Q')
  PPI_Net<-select(PPIdf,'from','to','combined_score')
  
  fn=paste(Spl,"_NodeRank.csv",sep="")
  write.csv(PLF_Rank, file =fn, row.names=FALSE)
  fn=paste(Spl,"_Network.csv",sep="")
  write.csv(PPI_Net, file =fn, row.names=FALSE)
}

GetPPI('HC')
GetPPI('MC')

#Get PPI with Betasheet
GetPPIwBS<-function(Spl){
  Spl='HC'
  df <- read_csv(paste(Spl,".csv",sep=""))
  #Convert String ID
  Sid<-ConvertID(df$ID,"ACC+ID", "STRING_ID")
  PLF<-merge(df,Sid, by.x="ID", by.y="From_UniProtKB_AC_ID")
  PLF<-PLF[PLF$`To STRING_ID`!="",] #remove empty STRING_ID
  PLF<-PLF[order(-PLF$Q),] # order the df in desceding by emPAI
  
  get_STRING_species(version="10", species_name=NULL)
  #human species 9606
  string_db <- STRINGdb$new( version="10", species=9606,score_threshold=0, input_directory="" )
  PPIdf<-string_db$get_interactions(PLF$`To STRING_ID`)
  PLF_Rank<-select(PLF,'ID',`To STRING_ID`,'Q','BP')
  PPI_Net<-select(PPIdf,'from','to','combined_score')
  
  fn=paste(Spl,"_NodeList.csv",sep="")
  write.csv(PLF_Rank, file =fn, row.names=FALSE)

}

