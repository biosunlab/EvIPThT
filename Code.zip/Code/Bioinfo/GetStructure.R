library(rvest)


protein_structure<-function(A){
  
  attribute=NULL
  unknow=NULL
  no_structure=NULL
  url_old="https://www.uniprot.org/uniprot/accession" 
  url_new=gsub("accession",A,url_old)
  
  ###read the summary table from uniprot
  table<- url_new %>%
    read_html() %>%
    html_nodes(xpath='//*[@id="secstructure_section"]') %>%
    html_table(fill=TRUE,header=TRUE)
  if (length(table)>0){
    n=nrow(table[[1]])
    
    ###get the length of protein sequence from uniprot
    seq.length<- url_new %>%
      read_html() %>%
      html_nodes(xpath='//*[@id="secondarystructure"]/svg/text[2]')%>%
      html_text()
    
    keyfeature=gsub(".*>","",table[[1]][,1]) 
    position=c(as.matrix(table[[1]][2]))
    PDB_ID=gsub(".*:","",table[[1]][,3])
    
    start=as.numeric(t(matrix(unlist(strsplit(position," – ")),2,n))[,1])
    end=as.numeric(t(matrix(unlist(strsplit(position," – ")),2,n))[,2])
    length=table[[1]][,5]
    percentage=as.numeric(length)/as.numeric(seq.length)
    info=data.frame(rep(A,n), keyfeature,start,end,length,PDB_ID,rep(seq.length,n),percentage)
    
    
    
    ###get the 3D structure table from uniprot database####
    table1<- url_new %>%
      read_html() %>%
      html_nodes(xpath='//*[@id="structure"]/table') %>%
      html_table(fill=TRUE,header=TRUE)
    id=which(grepl("PDB", table1[[1]][,1]))
    if(length(id)==0){
      table1<- url_new %>%
        read_html() %>%
        html_nodes(xpath='//*[@id="structure"]/table[2]') %>%
        html_table(fill=TRUE,header=TRUE)}
    
    
    id=which(grepl("PDB", table1[[1]][,1]))
    PDB_entry=table1[[1]][id,2]
    method=table1[[1]]$Method[id]
    Method_info=data.frame(PDB_entry[which(PDB_entry!="")],method[which(PDB_entry!="")])
    colnames(Method_info)=c("PDB_ID","method")
    attribute=merge(info, Method_info, all=TRUE )
    
    ######find the position for unknown
    if(start[1]!=1 & end[n]!=as.numeric(seq.length)){
      u_start=c(1,(end+1))
      u_end=c((start-1),as.numeric(seq.length))
    }  else if (start[1]==1 & end[n]!=as.numeric(seq.length))
    {u_start=(end+1)
    u_end=c((start[-1]-1),as.numeric(seq.length))
    }  else if (start[1]!=1 & end[n]==as.numeric(seq.length))
    {  u_start=c(1, end[-n]+1)
    u_end=(start-1)
    }  else{ u_start=end[-n]+1
    u_end=start[-1]-1 }
    
    U_start=u_start[-which(u_start %in% start)]
    U_end=u_end[-which(u_end %in% end)]
    unknow=data.frame(rep(A,length(U_end)),U_start,U_end)
  }
  else{no_structure=A}
  mylist=list("1"=attribute,"2"=unknow,"3"=no_structure)
  return(mylist)
  
}

HE=read.csv(file='%Your Local Data File%HE.csv',header=TRUE)
HE_No_structure=NULL
HE_All_attr=NULL
HE_ALL_unknow=NULL
for (j in 1:649){
  output=invisible(protein_structure(as.matrix(HE)[,1][j]))
  HE_All_attr=rbind(All_attr,output$'1')
  HE_ALL_unknow=rbind(ALL_unknow,output$'2')
  HE_No_structure=rbind(No_structure,output$'3')
}

HE_attribute=na.omit(HE_All_attr)


HE_BP=aggregate(HE_attribute[,8], by=list(Category=HE_attribute[,2]), FUN=sum)
colnames(HE_BP)=c("accession","BP")

write.csv(HE_attribute,file="%Your Local Data File%HE/HE_attribute.csv")
write.csv(HE_BP,file="%Your Local Data File%HE/HE_BP.csv")
write.csv(HE_ALL_unknow,file="%Your Local Data File%HE/HE_unknown.csv")
write.csv(HE_No_structure,file="%Your Local Data File%HE/HE No structure.csv")



ME=read.csv(file='%Your Local Data File%ME.csv',header=TRUE)
ME_No_structure=NULL
ME_All_attr=NULL
ME_ALL_unknow=NULL
for (j in 1:2844){
  output=invisible(protein_structure(as.matrix(ME)[,1][j]))
  ME_All_attr=rbind(ME_All_attr,output$'1')
  ME_ALL_unknow=rbind(ME_ALL_unknow,output$'2')
  ME_No_structure=rbind(ME_No_structure,output$'3')
}

ME_attribute=na.omit(ME_All_attr)


ME_BP=aggregate(ME_attribute[,8], by=list(Category=ME_attribute[,2]), FUN=sum)
colnames(ME_BP)=c("accession","BP")

write.csv(ME_attribute,file="%Your Local Data File%ME/ME_attribute.csv")
write.csv(ME_BP,file="%Your Local Data File%ME/ME_BP.csv")
write.csv(ME_ALL_unknow,file="%Your Local Data File%ME/ME_unknown.csv")
write.csv(ME_No_structure,file="%Your Local Data File%ME/ME No structure.csv")

